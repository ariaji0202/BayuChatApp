# BayuChat
This is the source code for BayuChat, a Flutter-based chat application with Firebase backend.

## How to build APK (auto)
- Push this repo to GitHub
- Go to the `Actions` tab
- Wait for workflow to complete
- Download `app-release.apk` from the artifacts
